The resources in this repository have been used in the course Statistics 102 in the Department of Statistics at Harvard University and are based on  the text Introductory Statistics for the Life and Medical Sciences (https://github.com/OI-Biostat/oi_biostat_text). Instructors may find the following sections useful.


*Problem Sets*

The repository contains problems sets from just one year, since many problems are reused throughout the years.  The problem sets are based on the assumption that students will be tested with-take home examinations, so the posted problem sets involve the use of R. 

Some problems have been adapted to appear as even numbered end-of-chapter exercises in the textbook, so that the solutions are not freely available to students.

- Problem Sets 1 - 3 contain material corresponding to the respective units.

- Problem Set 4 contains material in both Units 4 and 5 (stopping before ANOVA).

- Problem Set 5 contains material in both Units 5 and 6.

- Problem Set 6 is intended for students to use material from Units 5 and 6, but students are also welcome to use concepts from Unit 7.

- Problem Set 7 contains material from Unit 7.

- Problem Set 8 contains material from Units 8 and 9.
