#create water.new

set.seed(2019)
fluoride <- runif(175, 0, 2.5)
error <- rnorm(175, 0, 100)
caries <- 812 - 633*fluoride + 125*fluoride^2 + error

#added 12 Nov 2019
fluoride <- fluoride[caries > 0]
caries <- caries[caries > 0]

fluoride <- round(fluoride, 2)
caries <- round(caries, 2)

water.new <- cbind(fluoride, caries)
water.new <- as.data.frame(water.new)

save(water.new, file = "water_new.Rdata")


#assess curvature
plot(caries ~ fluoride)
abline(lm(caries ~ fluoride), col = "red")

plot(resid(lm(caries ~ fluoride)) ~ fitted(lm(caries ~ fluoride)))
abline(h = 0, lty = 2, col = "red")
