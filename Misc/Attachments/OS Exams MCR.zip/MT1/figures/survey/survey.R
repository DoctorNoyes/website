library(openintro)
library(downloader)
library(xtable)

download("https://stat.duke.edu/~mc301/data/surveyS15.csv", destfile = "surveyS15.csv") 

# Netflix
survey = read.csv("surveyS15.csv", stringsAsFactors = FALSE)
dim(survey)

survey = survey[survey$netflix_binge_show!= "Battlestar Galactica", ] 
survey$netflix_binge_show[survey$netflix_binge_show == "How I Met Your Mother"] = "HIMYM"
survey$cat_or_dog[survey$cat_or_dog == "I'm not an animal person"] = "Neither"

png("mosaic_catdog_netflix.png", width = 600, height = 400)
par(mar = c(0, 0, 0.1, 0))
mosaicplot(survey$cat_or_dog ~ survey$netflix_binge_show, col = COL[1], main = "", cex.axis = 1.5, las = 1)
dev.off()

xtable(addmargins(table(survey$netflix_binge_show, survey$cat_or_dog)), digits = 0)

# TV hours
survey = read.csv("surveyS15.csv", stringsAsFactors = FALSE)

survey = survey[survey$hours_watching_television <= 24 & !is.na(survey$hours_watching_television), ]
dim(survey)

summary(survey$hours_watching_television)

pdf("hist_tv_hours.pdf", width = 7, height = 3)
par(mar = c(2, 2, 0, 0))
hist(survey$hours_watching_television, main = "", xlab = "", ylab = "", col = COL[1])
dev.off()

sd(survey$hours_watching_television)
mean(survey$hours_watching_television)
