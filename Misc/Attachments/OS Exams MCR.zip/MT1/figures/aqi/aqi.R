# clear workspace ---------------------------------------------------

rm(list=ls())

# load packages -----------------------------------------------------

library(dplyr)
library(ggplot2)

# load data ---------------------------------------------------------

all <- read.csv("daily_44201_2015.csv", stringsAsFactors = FALSE) 

# subset for durham -------------------------------------------------

durham <- all %>%
  filter(County.Name == "Durham")

# summary stats -----------------------------------------------------

summary(durham$AQI)
sd(durham$AQI)

# histogram for durham aqis -----------------------------------------

durham_aqi_hist <- ggplot(data = durham, aes(x = AQI)) +
  geom_histogram(binwidth = 4, color = "gray") +
  theme_bw() +
  scale_y_continuous(breaks = seq(0, 20, 2), minor_breaks = seq(1, 20, 1)) +
  scale_x_continuous(breaks = seq(8, 72, 4), minor_breaks = seq(8, 72, 4))

ggsave(filename = "durham_aqi_hist.pdf", durham_aqi_hist, width = 8, height = 4)
