library(openintro)

movies = read.csv("top100_movies.csv")

pdf("hist_runtime.pdf", width = 7, height = 3)
par(cex.axis = 1.25, cex.lab = 1.25, mar = c(4,4,0,0), las = 1)
hist(movies$runtime, col = COL[1], main = "", xlab = "runtime (mins)", axes = FALSE, ylab = "")
axis(1)
axis(2, at = seq(5,30,5), label = seq(5,30,5)/100)
abline(h = seq(5,30,5), lty = 3, col = "gray")
dev.off()

st_runtime = (movies$runtime - mean(movies$runtime))/sd(movies$runtime)

pdf("qq_runtime.pdf", width = 3, height = 3)
par(cex.axis = 1, cex.lab = 1, mar = c(4,4.2,0.5,0.2))
qqnorm(st_runtime, pch = 19, col = COL[1,3], main = "")
qqline(st_runtime, col = COL[1])
dev.off()

n = 100
m = mean(movies$runtime)
s = sd(movies$runtime)

set.seed(123)
qq1 = rnorm(n)
qq2 = rbeta(n, 5, 1)
qq3 = rt(n, df=5)

pdf("qq1.pdf", width = 3, height = 3)
par(cex.axis = 1, cex.lab = 1, mar = c(4,4.2,0.5,0.2))
qqnorm(qq1, pch = 19, col = COL[1,3], main = "")
qqline(qq1, col = COL[1])
dev.off()

pdf("qq2.pdf", width = 3, height = 3)
par(cex.axis = 1, cex.lab = 1, mar = c(4,4.2,0.5,0.2))
qqnorm(qq2, pch = 19, col = COL[1,3], main = "")
qqline(qq2, col = COL[1])
dev.off()

pdf("qq3.pdf", width = 3, height = 3)
par(cex.axis = 1, cex.lab = 1, mar = c(4,4.2,0.5,0.2))
qqnorm(qq3, pch = 19, col = COL[1,3], main = "")
qqline(qq3, col = COL[1])
dev.off()
