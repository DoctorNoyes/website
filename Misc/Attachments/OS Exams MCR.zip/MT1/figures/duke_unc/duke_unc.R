# total sample size ------------------------------------------------

n_all <- 129

# calculate gender distribution ------------------------------------

p_woman <- 0.53
p_man <- 0.47

n_woman <- round(n_all * p_woman)
n_man <- round(n_all * p_man)

n_woman + n_man == n_all

# calculate distribution of duke vs. unc ----------------------------

(n_duke_woman <- round(n_woman * 0.26)) # 17
(n_duke_man <- round(n_man * 0.31))     # 18
(n_unc_woman <- round(n_woman * 0.42))  # 28
(n_unc_man <- round(n_man * 0.37))      # 22

# create dataset ----------------------------------------------------

duke <- c(rep("woman", n_duke_woman), rep("man", n_duke_man))
unc <- c(rep("woman", n_unc_woman), rep("man", n_unc_man))
gender <- c(duke, unc)
team <- c(rep("duke", length(duke)), rep("unc", length(unc)))

basket_root <- data.frame(gender, team)

# randomization -----------------------------------------------------

load(url("https://stat.duke.edu/~mc301/R/fun/inference.RData"))

results <- inference(data = basket_root, y = team, x = gender, success = "duke",
                     stat = "proportion",
                     type = "ht", method = "simulation", nsim = 200,
                     null = 0, alternative = "twosided", seed = 1957282)

results <- data.frame(sim_dist = results$sim_dist)

duke_unc_sim_dist <- ggplot(data = results, aes(x = sim_dist)) +
  geom_dotplot(dotsize = 0.7) +
  theme_bw() +
  ylab("") +
  xlab("simulated differences (man - woman)") +
  theme(axis.ticks.y = element_blank(),
        axis.text.y = element_blank()) +
  scale_x_continuous(breaks = seq(-0.08, 0.08, 0.02), minor_breaks = seq(-0.08, 0.08, 0.01))

ggsave(file = "duke_unc_sim_dist.pdf", duke_unc_sim_dist, width = 6, height = 4)
