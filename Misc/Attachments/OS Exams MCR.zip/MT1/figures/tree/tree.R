rm(list=ls())

library(openintro)

pdf("tree.pdf", width = 10, height = 4)
treeDiag(main = c("Drink","Detain"), out1 = c("drinking","not drinking"), p1 = c(0.12,1-0.12), out2 = c("detain","not detain"), p2 = list(c(0.90,0.10),c(0.10,0.90)), showWork = TRUE, digits = 4, solwd = 0.3)
dev.off()