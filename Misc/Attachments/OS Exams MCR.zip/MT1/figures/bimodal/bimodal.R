rm(list=ls())

library(openintro)

set.seed(123)
d1 = c(rnorm(100,30,4), rnorm(100,50,4))
summary(d1)
d1[which.min(d1)] = 18
d1[which.max(d1)] = 66

d2 = c(rnorm(200, 40, 10))
summary(d2)
d2[which.min(d2)] = 18
d2[which.max(d2)] = 66



pdf("box.pdf", width = 8, height = 3)
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.5)
boxplot(d1, horizontal = TRUE)
dev.off()


pdf("hist1.pdf", width = 7, height = 5)
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.75)
hist(d1, col = COL[1], axes = FALSE, main = "")
axis(1)
dev.off()

pdf("hist2.pdf", width = 7, height = 5)
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.75)
hist(d2, col = COL[1], axes = FALSE, main = "")
axis(1)
dev.off()

pdf("hist3.pdf", width = 7, height = 5)
d3 = c(rnorm(100,0,10), rnorm(100,80,10))
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.75)
hist(d3, col = COL[1], axes = FALSE, main = "")
axis(1, at = seq(-30,100,20))
dev.off()

pdf("hist4.pdf", width = 7, height = 5)
d4 = rbeta(100,1,40)*1000
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.75)
hist(d4, col = COL[1], axes = FALSE, main = "")
axis(1, at = seq(0,140,20))
dev.off()

pdf("hist5.pdf", width = 7, height = 5)
d5 = rbeta(100,5,1)*100
par(mar=c(2,0.25,0.25,0.25), cex.axis = 1.75)
hist(d5, col = COL[1], axes = FALSE, main = "")
axis(1, at = seq(20,100,20))
dev.off()


