rm(list=ls())

library(openintro)
library(downloader)
library(xtable)
library(BHH2)

basic = c(7, 10, 10.6, 10.2, 8.6, 7.6, 8.2, 10.4, 11, 8.5)
extended = c(3.4,7.8, 9.4, 4.7, 5.4, 7.6, 5.0, 8.0, 7.8, 9.6)

time = c(basic, extended)
type = c(rep("basic", length(basic)), rep("extended", length(extended)))

pdf("hist_basic_extended.pdf", width = 6, height = 2.2)
par(mfrow = c(1,2), cex.axis = 1, cex.lab = 1, mar = c(4,3,1,0))
hist(basic, col = COL[1], main = "Basic", xlab = "commercials (mins)")
hist(extended, col = COL[1], main = "Extended", xlab = "commercials (mins)")
dev.off()

by(time, type, mean)
round(by(time, type, sd),2)

by(time, type, mean)[1] - by(time, type, mean)[2]

download("https://stat.duke.edu/~mc301/R/inference.RData", destfile = "inference.RData")
load("inference.RData")

simdist = inference(time, type, method = "simulation", type = "ht", est = "mean", alternative = "twosided", nsim = 200, inf_lines = FALSE, null = 0, eda_plot = FALSE, seed = 2000, simdist = TRUE)

pdf("commercials_rand.pdf", width = 7, height = 3)
par(mar = c(4,0,0,0))
BHH2::dotPlot(simdist, pch = 19, xlab = "basic - extended", axes = FALSE)
axis(1, at = seq(-2.5, 2.5, 0.5))
abline(v = seq(-2.5, 2.5, 0.25), col = "gray", lty = 2)
dev.off()