# clear workspace ---------------------------------------------------

rm(list=ls())

# load packages -----------------------------------------------------

library(ggplot2)

# create data -------------------------------------------------------

A = c(rep(5, 5), rep(8.5, 20), rep(12, 5))

B = c(rep(5, 14), rep(8.5, 2), rep(12, 14))

C = rep(seq(5, 12, 0.5), each = 2)

d = data.frame(A, B, C)

# histograms -------------------------------------------------------

hist_A <- ggplot(d, aes(A)) +
  geom_histogram(binwidth = 0.5) +
  scale_x_continuous(breaks = seq(5, 12, 1)) +
  ylim(0, 20) +
  theme_bw()

ggsave(hist_A, file = "histA.pdf", width = 3.75, height = 2.5)

hist_B <- ggplot(d, aes(B)) +
  geom_histogram(binwidth = 0.5) +
  scale_x_continuous(breaks = seq(5, 12, 1)) +
  ylim(0, 20) +
  theme_bw()

ggsave(hist_B, file = "histB.pdf", width = 3.75, height = 2.5)

hist_C <- ggplot(d, aes(C)) +
  geom_histogram(binwidth = 0.5) +
  scale_x_continuous(breaks = seq(5, 12, 1)) +
  ylim(0, 20) +
  theme_bw()

ggsave(hist_C, file = "histC.pdf", width = 3.75, height = 2.5)



