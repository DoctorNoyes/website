mdma: simulated data

midterm_genomics: based on data from Kostic, AD, et al. Genomic analysis identifies association of Fusobacterium with colorectal carcinoma. Genome Research 22:292-298 (2012).

pheno_abundance: simulated data

self_manage: data from Bos-Touwen, I, et al. Patient and disease characteristics associated with activation for self-management in patients with diabetes, chronic obstructive pulmonary disease, chronic heart failure and chronic renal disease: a cross-sectional survey study. PLoS ONE 10(5): e0126400. 2015.

vitamin_d: data from Houghton, LA, et al. Vitamin D status among Thai school children and the association with 1,25-dihydroxyvitamin D and parathyroid hormone levels. PLoS ONE 9(8): e103825. 2014.