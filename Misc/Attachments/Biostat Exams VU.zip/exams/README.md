The resources in this repository have been used in the course Statistics 102 in the Department of Statistics at Harvard University and are based on the text Introductory Statistics for the Life and Medical Sciences (https://github.com/OI-Biostat/oi_biostat_text). Instructors may find the following sections useful.

*Exams*

Exams from 2014 - 2020 (with exception of 2018) are provided with full solutions, for both midterm and final examinations.  The 2014 and 2015 exams were administered as standard 50 minute in class exams; all remaining examinations were administered as take-home exams. The target time commitment for the take-home exams was 10-15 hours of time outside of class; the exams were due 7-10 days after being posted.  Students were expected to work independently, but were free to access lecture notes, refer to the textbook, etc.

Just like the labs for the course (https://github.com/OI-Biostat/oi_biostat_labs), students were provided with Markdown templates for the take home exams.

Source files (R Markdown or LaTeX) and pdf versions are provided for all exams.  The datasets needed for the exams can be found in the dataset folders in the midterm_exam and final_exam folders. Where exam problems draw from published data, certain details of the setting were obscured to prevent students from finding publications online. References to datasets are provided in README files in the exam dataset directories.

Some exam questions have been adapted as end-of-chapter exercises in the textbook.
