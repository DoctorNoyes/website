anemia: data from Houghton LA, et al. Multiple micronutrient status and predictors of anemia in young children aged 12-23 months living in New Delhi, India. PLoS ONE 14(2): e0209564. 2019.

antibiotics_2010, antibiotics_2011, antibiotics_overall: data from Kliemann BS, et al. Socioeconomic determinants of antibiotic consumption in the state of Sao Paolo, Brazil: the effect of restricting over-the-counter sales. PLoS ONE 11(12): e0167885. 2016.

arenosa_rnaseq: data from Baduel, P, et al. Habitat-associated life history and stress-tolerance variation in Arabidopsis arenosa. Plant Physiology 171: 437-451. 2016.

blood_pressure: simulated data

bone_density: data from Hopper JL and E Seeman. The bone density of female twins discordant for tobacco use. NEJM 330(6): 387- 392. 1994.

forest_birds: data in Experimental Design and Data Analysis for Biologists, by Gerry Quinn and Michael Keough. Cambridge University Press. data from Loyn, RH 1987. full citation in text.

quality_of_life: simulated data

resilience: data from Tempski, P, et al. Relationship among medical student resilience, educational environment and quality of life. PLoS ONE 10(6): e0131535. 2015.

rubythroats: data from Potti, J, et al. Lifetime fitness and age-related female ornament signalling: evidence for survival and fecundity selection in the pied flycatcher. Journal of Evolutionary Biology 26: 1445-1457. 2013.

tb: data from Lackey, B, et al. Patient characteristics associated with tuberculosis treatment default: a cohort study in a high-incidence area of Lima, Peru. PLoS ONE 10(6): e0128541. 2015.